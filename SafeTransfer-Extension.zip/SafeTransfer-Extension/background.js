// SafeTransfer Extension - Background Service Worker

// Listen for installation
chrome.runtime.onInstalled.addListener((details) => {
    console.log('SafeTransfer Extension installed:', details.reason);

    // Set default settings
    chrome.storage.local.set({
        settings: {
            autoDetect: true,
            showNotifications: true,
            safetransferUrl: 'https://safetransfer-pi.vercel.app'
        }
    });
});

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Background received message:', message);

    switch (message.type) {
        case 'CAPTURE_DATA':
            handleCaptureData(message.data, sender.tab);
            sendResponse({ success: true });
            break;

        case 'OPEN_SAFETRANSFER':
            openSafeTransferWithData(message.data);
            sendResponse({ success: true });
            break;

        case 'GET_SETTINGS':
            chrome.storage.local.get('settings', (result) => {
                sendResponse(result.settings || {});
            });
            return true; // Keep channel open for async response
    }
});

// Handle captured data
async function handleCaptureData(data, tab) {
    try {
        // Store the captured data
        await chrome.storage.local.set({
            lastCapture: {
                data: data,
                timestamp: Date.now(),
                source: tab?.url || 'unknown'
            }
        });

        // Show notification
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'SafeTransfer',
            message: 'Datos capturados correctamente'
        });

    } catch (error) {
        console.error('Error handling capture:', error);
    }
}

// Open SafeTransfer with captured data
async function openSafeTransferWithData(data) {
    const settings = await chrome.storage.local.get('settings');
    const baseUrl = settings.settings?.safetransferUrl || 'https://safetransfer-pi.vercel.app';

    const params = new URLSearchParams({
        action: 'import',
        data: JSON.stringify(data)
    });

    chrome.tabs.create({
        url: `${baseUrl}?${params.toString()}`
    });
}

// Context menu for quick actions (optional)
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: 'captureSelection',
        title: 'Capturar selección para SafeTransfer',
        contexts: ['selection']
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'captureSelection' && info.selectionText) {
        // Store selected text for manual entry
        chrome.storage.local.set({
            selectedText: info.selectionText
        });

        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'SafeTransfer',
            message: 'Texto seleccionado guardado. Abre la extensión para continuar.'
        });
    }
});
